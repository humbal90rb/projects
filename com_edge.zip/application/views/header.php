<!DOCTYPE html>
<html>
<head>
<title></title>
<link rel="stylesheet" type="text/css" href=<?php echo base_url("assets/css/bootstrap.css"); ?>  >
<script type="text/javascript" src= <?php echo base_url("assets/js/jquery.js"); ?>  ></script>
<script type="text/javascript" src= <?php echo base_url("assets/js/bootstrap.js"); ?>  ></script>
<script type="text/javascript" src= <?php echo base_url("assets/js/script.js"); ?>  ></script>

</head>
<body>