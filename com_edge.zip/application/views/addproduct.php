<?php
include 'header.php';
include 'navbar.php';
?>
<div class="row">
<div class="col-md-offset-4 col-md-4">
<div class="panel panel-default">
	<div class="panel-heading"><h2 class="text">New Product</h2></div>
  <div class="panel-body">
  <form action="<?php echo base_url('Addproduct/addProduct'); ?>" method="post">
  	<input type=text class="form-control input-md" name="name" placeholder="Product Name">
  	<input type=number class="form-control input-md" name="price" placeholder="Price">
  	<input type=number class="form-control input-md" name="accessid" placeholder="Access Id">
  	<input type=submit class="form-control btn btn-info btn-block" name="add" value="Add Product">
  </form>
  </div>
  <div class="panel-footer"><p class="text">All fields Required!</p></div>
</div>
</div>
</div>
<?php 			
	include 'footer.php';
?>
