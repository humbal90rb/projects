<?php 
	include ('header.php');
	include ('navbar.php');
?>

<button id="btn">Click</button>

<?php
include ('footer.php');
?>