<?php
include 'header.php';
include 'navbar.php';
?>
<?php 
include 'footer.php';
?>