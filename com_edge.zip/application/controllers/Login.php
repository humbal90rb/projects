<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Login extends CI_Controller{
	
	function __construct()
	{
		parent::__construct();
		 if($this->session->userdata('isLoggedIn'))
		{
		redirect(base_url('dashboard'));
		}  
	}
	function index(){
		$this->load->view('login');		
	}
	function userAthentication ()
	{
		$username = $this->input->post('username');
		$password = $this->input->post('password');
		$this->load->model('Athentication');
		$res = $this->Athentication->userAth($username,$password);
		if($res > 0)
		{
			$this->session->set_userdata('isLoggedIn',true);
			$this->session->set_userdata('name',$res->name);
			redirect(base_url('dashboard'));
		}else 
		{
			echo "<script> alert ('Invalid Username/Password!');</script>";
			redirect(base_url('login'));
		}
		
	}
	
	
}

?>