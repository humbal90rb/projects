<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Signup extends CI_Controller{
	
	function __construct()
	{
		parent::__construct();
	}
	function index(){
		
	 $this->load->view('signup');
		
	}
	function addUser ()
	{
		$name =$this->input->post('name');
		$username =$this->input->post('username');
		$password = $this->input->post('password');
		if (empty($name) || empty($username) || empty($password))
		{
			echo "<script> alert ('All fields required!');</script>";
			echo "<script> window.location = '".base_url('signup')."' ;</script>";
		}
		else {
		$this->load->model('register');
		$res =  $this->register->addUser($name,$username,$password);
		if ($res)
		 {
			echo "<script> alert ('User Registered!'); </script>";
			$this->session->set_userdata('isLoggedIn',true);
			$this->session->set_userdata('name',$name);
			redirect(base_url('dashboard'));
		}else
		{
		echo "<script> alert ('Some Error!'); </script>";
		redirect(base_url('signup'));
		}
	}
	}
	
}

?>