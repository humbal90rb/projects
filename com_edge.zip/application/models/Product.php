<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Product extends CI_Model{
	
	
	function addPro($name,$price,$accessid)
	{
		$data = array(
				'name' => $name,
				'price' => $price,
				'accessid' => $accessid
		);
		$query = $this->db->insert('products',$data);
		return $query;
	}
	function showPro(){
	 $data = $this->db->get('products');
	 return $data->result();
		
	}
	
}

?>