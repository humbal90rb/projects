$(document).ready(function(){
	$('#btn').click(function(){
		
		alert("btn clicked");
		
	});
	$('#btn').mouseenter(function(){
		
		alert("btn clicked");
		
	});
	
});