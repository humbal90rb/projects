<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Product extends CI_Model{
	
	
	function addPro($name,$price,$accessid)
	{
		$data = array(
				'name' => $name,
				'price' => $price,
				'accessid' => $accessid
		);
		$query = $this->db->insert('products',$data);
		return $query;
	}
	function showPro(){
	 $data = $this->db->get('products');
	 return $data->result();
		
	}
	function showproduct($accessid)
	{
		$data = array('accessid' => $accessid);
		$query = $this->db->get_where('products',$data);
		return $query->row();
	}
	function updatePro($oldaccessid,$name,$price,$accessid)
	{
		$data = array(
				'name' => $name,
				'price' => $price,
				'accessid' => $accessid
		);
		$this->db->set($data);
		$this->db->where('accessid',$oldaccessid);
	    $res = 	$this->db->update('products',$data);
		return $res;
		
	}
	function getProduct($accessid){
		$this->db->where('accessid',$accessid);
		$res =  $this->db->get('products');
		return $res->row();
	}
	function saveCustomer($name,$phone,$address){
		$data = array(
			"name"=>$name,
			"mobile"=>$phone,
			"address"=>$address
		);
		$res = $this->db->insert("customers",$data);
		return $res;
	}
}

?>