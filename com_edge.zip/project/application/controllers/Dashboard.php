<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

 class Dashboard extends CI_Controller{

			function __construct()
			{
				parent::__construct();
				 if(!$this->session->userdata('isLoggedIn'))
				{
					redirect(base_url(Login));
				}
			}
	 	function index()
			{
			$this->load->view('dashboard');	
			}
		public function getData()
		{
			$accessid = $_POST['accessid'];
			
			
			
			$this->load->model('product');
			$product = $this->product->getProduct($accessid);
			
			
			echo json_encode($product);
			
			
		}	
		public function customer(){
			
			$name = $_POST['name'];
			$phone = $_POST['phone'];
			$address = $_POST['address'];
			$this->load->model('product');
			$res = $this->product->saveCustomer($name,$phone,$address);
			if($res) echo "ok";
		}
	
}

 ?>