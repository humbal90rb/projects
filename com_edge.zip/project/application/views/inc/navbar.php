<nav class="navbar navbar-inverse navbar-default">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="<?php echo base_url('') ;?>">WebSiteName</a>
    </div>
    <ul class="nav navbar-nav">
      <li class=""><a href="<?php echo base_url('') ;?>">Home</a></li>
      <li><a href="<?php echo base_url('Addproduct') ;?>">Add New Product</a></li>
      <li><a href="<?php echo base_url('Showproduct') ;?>">Show Products</a></li>
    </ul>
    <ul class="nav navbar-nav navbar-right">
      <li><a href=""><?php echo $this->session->userdata('name') ; ?> </a></li>
       <li><a href="<?php echo base_url('logout'); ?>"><span class="glyphicon glyphicon-log-out"></span> Logout </a></li>
    </ul>
  </div>
</nav>