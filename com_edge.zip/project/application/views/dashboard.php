<?php 
	include ('inc/header.php');
	include ('inc/navbar.php');
?>
<style type="text/css">

	@media print {
					.printable_div	{
						display:block; 
						width:300px;
						}
					.notPrinted{
						display:none;
					}
					.print_view{
						border:1px solid black;
					
					}
					#print_name{
						width:50%;
						float:left;
					}
					
					#print_date{
						width:50%;
						float:left;
					}
				}
</style>
<!-- <button id="btn">Click</button> -->

<div class="row">
<div class="col-md-3" >
<div class="print_view" align="center">
		<div class="printable_div"  id="printable_div" align="center">
		<img   src="<?php echo site_url(); ?>assets/admin/img/logo/logo_1.png" alt="" /><br>
		<span>P-147/O Hall Road Lahore</span><br>
		<span>Phone:041-1234567</span><br>
		<div class="row" align="left">
			<div class="col-md-6" id="print_name" style="">
			</div>
			<div class="col-md-6" id="print_date" style="">
			</div>
		</div>
		
		<div class="row">
		<div class="col-md-12">
        <table class="table" id="item_detail">
		<tr>
		<td>Item</td>
		<td>Qty</td>
		<td>U.Price</td>
		<td>Total</td>
		</tr>
		</table>
		</div>
		</div>
		<div class="row">
			<div class="col-md-12" align="left">
			<p>Total Items:<span id="total_items">0</span></p>
			</div>
		</div>
		<div class="row">
			<div class="col-md-12" align="right">
			<div id="gross_total" ></div>
			</div>
		</div>
		<div class="row">
			<div class="col-md-12" align="right">
			<div  id="discount" ></div>
			</div>
			</div>
		<div class="row" >
			<!--<div class="col-md-4"><strong>Kashif</strong></div>
			<div class="col-md-8" align="left">
			<div class="col-md-6" >Net Total:</div>
			<div class="col-md-6" id="net_total" ></div>
			</div>-->
			<ul align="left" style="line-height:1;text-align:justify;text-justify:inter-word;">
			<li id="notes" style="line-height:1;">Before leaving the counter, please check the balance amount.</li>
			<li id="notes" style="line-height:1;">Items will not be refunded or exchanged after 15 days of purchase.</li>
			<li id="notes" style="line-height:1;">Thanks for shopping, hope to see you soon.</li>
			</ul>
			<p style="line-height:1;">Computer Software developed by Humbal humbal90rb@gmail.com<p>
		</div>
		
    </div>
	</div>
</div>
<div class="notPrinted">
<div class="col-md-6">
<h3>Bill</h3>
<div class="row">

<div class="col-md-4"><input  type=text id="accessid" class="form-control input-lg" name="accessId" placeholder="Access Id"   ></div>
<div class="col-md-4"><input type=text data-default ="1" id="quantity" class="form-control input-lg" name="quantity" placeholder="Quantity"   onBlur="document.getElementById('accessid').focus(); test();"></div>
<div class="col-md-4"><input type="text" data-default ="0" value="0" id="total" type="text"  class="form-control input-lg"  placeholder="Total"></div>
<table class="table" id="demo" >
	<tr>
		<th>Product</th>
		<th>Unit Price</th>
		<th>Quantity</th>
		<th>Total</th>
	<tr>
	
</table>
</div>
</div>
<div class="col-md-3">
<h3>Customer Detail </h3>
<div class="panel panel-default">
	<div class="panel-heading"><h4>Customer Detail</h4> <div id="cusRes"></div></div>
  <div class="panel-body">
  	<input type=text class="form-control input-md" name="name" id="name"  placeholder="Name" autofocus>
  	<input type=text class="form-control input-md" name="phone" id="phone" placeholder="Phone Number">
  	<input type=text class="form-control input-md" onBlur="customer();" name="address" id="address" placeholder="Address">
  	<!--<input type=submit class="form-control btn btn-info btn-block" id="addCus" name="addCus" value="Save Information">-->
  </div>
 
</div>
<div width=100% align=center >
<input type="button" id="btnPrint" class="btn" onclick="printDate();"  value="Print" accesskey="p"/>
<input type="button" id="btnRefresh" class="btn" onclick="window.location = 'http://localhost/project/';"  value="Refresh" accesskey="n"/>
<input type="button" id="btnCancel" class="btn" onclick="resetInput()"  value="Cancel" accesskey="c"/>
</div>
</div>
</div>

<?php
include ('inc/footer1.php');
?>
<script type="application/javascript">
		function resetInput(){
			$(document).find('input[type=text]').each(function(){
			  var defaultVal = $(this).data('default');
			  $(this).val(defaultVal);
			});
		}
		
			$("#btnPrint").click(function () {
			$(".printable_div").print();
			});

			
			$(document).ready(function(){$(document).keypress(function (e) {
			if (e == 13 ) {print();}
			});});
			
	



		function test(){	
		var accessid = $('#accessid').val();
		var quantity = $('#quantity').val();
		var div = document.getElementById("demo");
		var div1 = document.getElementById("item_detail");
		$.post("http://localhost/project/dashboard/getData",{accessid:accessid}).done(function(data){
			
			var pro = JSON.parse(data);
			if(pro.name == undefined){alert("Wrong Access Id!"); return false;}
			var p_total = $('#total').val();
			var b = parseInt(p_total);
			var pro_total = pro.price * quantity;
			var c = b + pro_total; //total calculation error is in this line
			div.innerHTML = div.innerHTML + "<tr><td>" + pro.name + "</td><td>" + pro.price + "</td><td>" + quantity + "</td><td>"+ pro_total +"</td></tr>";
			div1.innerHTML = div1.innerHTML + "<tr><td>" + pro.name + "</td><td>" + quantity + "</td><td>" + pro.price + "</td><td>"+ pro_total +"</td></tr>";
			
			 document.getElementById("total").value = c;
			 document.getElementById("gross_total").innerHTML = "Gross Total: " + c;
			 document.getElementById("discount").innerHTML = "Discount: 0.00";
			var total_items = document.getElementById("total_items").innerHTML;	
			var a = parseInt(total_items);
			if(a == "")
			{
				a = 1; 
			}
			else
			{
				a = a + 1;
			}
			document.getElementById("total_items").innerHTML = a;
		});
		}
		//save customer detail
		function customer(){
		var name = $('#name').val();
		var phone = $('#phone').val();
		var address = $('#address').val();
		$.post("http://localhost/project/dashboard/customer",{name:name,phone:phone,address:address}).done(function(data){
			document.getElementById("cusRes").innerHTML = "<div id='ok_sign'><center><span class='glyphicon glyphicon-ok'></span></center></div>";
			document.getElementById("print_name").innerHTML ="Name."+name;
			
				
		});
		}
		
			
		
		
		/* 
		function print() { 	
		
        var contents = $("#dvContents").html();
        var frame1 = $('<iframe />');
        frame1[0].name = "frame1";
        frame1.css({ "position": "absolute", "top": "-1000000px" , "margin-left":"auto" });
        $("body").append(frame1);
        var frameDoc = frame1[0].contentWindow ? frame1[0].contentWindow : frame1[0].contentDocument.document ? frame1[0].contentDocument.document : frame1[0].contentDocument;
        frameDoc.document.open();
        //Create a new HTML document.
        frameDoc.document.write('<html><head><title>Print Receipt</title>');
        frameDoc.document.write('<style> .row {background-color:black;}</style>');
        frameDoc.document.write('</head><body>');
        //Append the external CSS file.
        frameDoc.document.write('<link href="http://localhost/project/assets/css/style.css" rel="stylesheet" type="text/css" />');
        //Append the DIV contents.
        frameDoc.document.write(contents);
		//Close the HTML document
        frameDoc.document.write('</body></html>');
        frameDoc.document.close();
        setTimeout(function () {
            window.frames["frame1"].focus();
            window.frames["frame1"].print();
            frame1.remove();
        }, 500);
		$('#ok_sign').fadeOut(); 
		} */
		function printDate(){
		var todayTime = new Date();
		var month = todayTime .getMonth() + 1;
		var day = todayTime .getDate();
		var year = todayTime .getFullYear();
		var hour = todayTime .getHours();
		hour = hour % 12;
		hour = hour ? hour : 12;
		var min = todayTime .getMinutes();
		var sec = todayTime .getSeconds();
		document.getElementById("print_date").innerHTML = day+"/"+month+"/"+year+" "+hour+":"+min+":"+sec;
		window.print();
		}
		
		
		
</script>
<?php
include ('inc/footer.php');
?>