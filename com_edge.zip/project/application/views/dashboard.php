<?php 
	include ('inc/header.php');
	include ('inc/navbar.php');
?>
<style type="text/css">

	@media print {
					.printable_div	{
						display:block; 
						width:500px;
						}
					.notPrinted{
						display:none;
					}
					.print_view{
						border:0px solid black;
					
					}
					#print_name{
						width:50%;
						float:left;
					}
					
					#print_date{
						width:50%;
						float:right;
					}
				}
				@media screen {
				.print_view{
						display:none;
					}
				}
</style>
<!-- <button id="btn">Click</button> -->
<div class="row" style=""> 
	<div class="col-md-12"> 
	<nav class="navbar navbar-default">
		<div class="container-fluid">
		
		<p class="navbar-text "><strong>Customer Detail</strong></p>
		<form class="navbar-form navbar-left">
		<div class="form-group">
		  <label for="name">Name:</label>
		  <input type=text class="form-control" name="name" id="name"  placeholder="Name" >
		</div><div class="form-group">
		  <label for="address">Address:</label>
		  <input type=text class="form-control"  name="address" id="address" placeholder="Address">
		</div>
		<div class="form-group">
		  <label for="phone">Contact No:</label>
		  <input type=text class="form-control" name="phone" onBlur="customer();" id="phone" placeholder="Phone Number">
		</div>
		<div class="form-group"id="cusRes" ></div>
		</form>
		<ul class="nav navbar-nav navbar-right">
		<div class="btn-group">
		<input type="button" id="btnPrint" class="btn navbar-btn btn-success" onclick="printDate();"  value="Print" accesskey="p"/>
		<input type="button" id="btnRefresh" class="btn navbar-btn btn-success" onclick="window.location = 'http://localhost/project/';"  value="Refresh" accesskey="n"/>
		<input type="button" id="btnCancel" class="btn navbar-btn btn-success" onclick="resetInput()"  value="Cancel" accesskey="c"/>
		</div>
		</ul>
	    </div>
	</nav>
	</div>
</div>
<div class="row">
<div class="print_view" align="center">
		<div class="printable_div"  id="printable_div" align="center">
		<img   src="<?php echo site_url(); ?>assets/admin/img/logo/logo_1.png" alt="" /><br>
		<span>P-147/O Hall Road Lahore</span><br>
		<span>Phone:041-1234567</span><br>
		<div class="row" align="left">
			<div class="col-md-6" align="left" id="print_name" style="">
			</div>
			<div class="col-md-6" align="right" id="print_date" style="">
			</div>
		</div>
		
		<div class="row">
		<div class="col-md-12">
        <table class="table" id="item_detail">
		<tr>
		<td>Sr#</td>
		<td>Item</td>
		<td>Qty</td>
		<td>U.Price</td>
		<td>Total</td>
		<td>Discount</td>
		<td>Dis.Ammount</td>
		<td>Net Price</td>
		</tr>
		</table>
		</div>
		</div>
		<div class="row">
			<div class="col-md-12" align="left">
			<p>Total Items:<span id="total_items">0</span></p>
			</div>
		</div>
		<div class="row">
			<div class="col-md-12" align="right">
			<div id="gross_total" ></div>
			</div>
		</div>
		<div class="row">
			<div class="col-md-12" align="right">
			<p>Discounted Ammount:<span id="discount">0</span></p>
			</div>
			</div>
		<div class="row" >
			<!--<div class="col-md-4"><strong>Kashif</strong></div>
			<div class="col-md-8" align="left">
			<div class="col-md-6" >Net Total:</div>
			<div class="col-md-6" id="net_total" ></div>
			</div>-->
			<ul align="left" style="line-height:1;text-align:justify;text-justify:inter-word;">
			<li id="notes" style="line-height:1;">Before leaving the counter, please check the balance amount.</li>
			<li id="notes" style="line-height:1;">Items will not be refunded or exchanged after 15 days of purchase.</li>
			<li id="notes" style="line-height:1;">Thanks for shopping, hope to see you soon.</li>
			</ul>
			<p style="line-height:1;">Computer Software developed by Humbal humbal90rb@gmail.com<p>
		</div>
		
    </div>
	</div>

<div class="notPrinted">
<div class="col-md-12">
<div class="row">

<div class="col-md-3"><input  type=text id="accessid" class="form-control input-lg" name="accessId" placeholder="Access Id" ></div>
<div class="col-md-3"><input  type=text id="discount_amount" class="form-control input-lg" name="discount" placeholder="Discount"></div>
<div class="col-md-3"><input type=text data-default ="1" id="quantity" class="form-control input-lg" name="quantity" placeholder="Quantity"   onBlur="document.getElementById('accessid').focus(); test();"></div>
<div class="col-md-3"><input type="text" data-default ="0" value="0" id="total" type="text"  class="form-control input-lg"  placeholder="Total"></div>



</div>
	<div class="row">
		<div class="col-md-12">
		<table class="table" id="demo" >
			<tr>
				<th>Sr#</th>
				<th>Product</th>
				<th>Unit Price</th>
				<th>Quantity</th>
				<th>Total</th>
				<th>Discount</th>
				<th>Ammount Discount</th>
				<th>Net Price</th>
			<tr>
			
		</table>
		</div>
		<div class="col-md-offset-9 col-md-3">Discounted Ammount<div id="show_discount_amount">0</div></div>
	</div>
</div>

</div>

<?php
include ('inc/footer1.php');
?>
<script type="application/javascript">
		function resetInput(){
			$(document).find('input[type=text]').each(function(){
			  var defaultVal = $(this).data('default');
			  $(this).val(defaultVal);
			});
			var demo_content = "<tr><th>Sr#</th><th>Product</th><th>Unit Price</th><th>Quantity</th><th>Total</th><th>Discount</th><th>Ammount Discount</th><th>Net Total</th><tr>";
			var item_detail_content = "<tr><td>Sr#</td><td>Item</td><td>Qty</td><td>U.Price</td><td>Total</td><td>Discount</td>	<td>Dis.Ammount</td><td>Net Price</td></tr>";
			
			document.getElementById("print_name").innerHTML = "";
			document.getElementById("print_date").innerHTML = "";
			document.getElementById("demo").innerHTML = demo_content;
			document.getElementById("item_detail").innerHTML = item_detail_content;
			document.getElementById("total_items").innerHTML = "0";
			document.getElementById("gross_total").innerHTML = "";
		}
		
			$("#btnPrint").click(function () {
			$(".printable_div").print();
			});

			
			$(document).ready(function(){$(document).keypress(function (e) {
			if (e == 13 ) {print();}
			});});
			
	



		function test(){	
		var accessid = $('#accessid').val();
		var discount = $('#discount_amount').val();
		var quantity = $('#quantity').val();
		
		var div = document.getElementById("demo");
		var div1 = document.getElementById("item_detail");
		
		
		$.post("http://localhost/project/dashboard/getData",{accessid:accessid}).done(function(data){
			
			var pro = JSON.parse(data);
			if(pro.name == undefined){alert("Wrong Access Id!"); return false;}
			var p_total = $('#total').val();
			var b = parseInt(p_total);
			var pro_total = pro.price * quantity;
			var discounted_ammount = (pro_total/100)*discount;
			var discounted_ammount = parseInt(discounted_ammount);
			var pro_net_price = pro_total-discounted_ammount;
			var pro_net_price = parseInt(pro_net_price);
			var c = b + pro_net_price;
			var total_items = document.getElementById("total_items").innerHTML;	
			var a = parseInt(total_items);
			var total_discounted_ammount = document.getElementById("discount").innerHTML;	
			total_discounted_ammount = parseInt(total_discounted_ammount);
			total_discounted_ammount = total_discounted_ammount + discounted_ammount;
			if(a == "")
			{
				a = 1; 
			}
			else
			{
				a = a + 1;
			}
			div.innerHTML = div.innerHTML + "<tr><td>" + a + "</td><td>" + pro.name + "</td><td>" + pro.price + "</td><td>" + quantity + "</td><td>"+ pro_total +"</td><td>"+ discount +"%</td><td>"+ discounted_ammount +"</td><td>"+ pro_net_price +"</td></tr>";
			div1.innerHTML = div1.innerHTML + "<tr><td>" + a + "</td><td>" + pro.name + "</td><td>" + quantity + "</td><td>" + pro.price + "</td><td>"+ pro_total +"</td><td>"+ discount +"%</td><td>"+ discounted_ammount +"</td><td>"+ pro_net_price +"</td></tr>";
			document.getElementById("total").value = c;
			document.getElementById("total_items").innerHTML = a;
			document.getElementById("gross_total").innerHTML = "Gross Total: " + c;
			document.getElementById("discount").innerHTML = " "+total_discounted_ammount;
			
		});
		}
		//save customer detail
		function customer(){
		var name = $('#name').val();
		var phone = $('#phone').val();
		var address = $('#address').val();
		$.post("http://localhost/project/dashboard/customer",{name:name,phone:phone,address:address}).done(function(data){
			document.getElementById("cusRes").innerHTML = "<div id='ok_sign'><center><span class='glyphicon glyphicon-ok'></span></center></div>";	
		});
		}
		
			
		
		
		/* 
		function print() { 	
		
        var contents = $("#dvContents").html();
        var frame1 = $('<iframe />');
        frame1[0].name = "frame1";
        frame1.css({ "position": "absolute", "top": "-1000000px" , "margin-left":"auto" });
        $("body").append(frame1);
        var frameDoc = frame1[0].contentWindow ? frame1[0].contentWindow : frame1[0].contentDocument.document ? frame1[0].contentDocument.document : frame1[0].contentDocument;
        frameDoc.document.open();
        //Create a new HTML document.
        frameDoc.document.write('<html><head><title>Print Receipt</title>');
        frameDoc.document.write('<style> .row {background-color:black;}</style>');
        frameDoc.document.write('</head><body>');
        //Append the external CSS file.
        frameDoc.document.write('<link href="http://localhost/project/assets/css/style.css" rel="stylesheet" type="text/css" />');
        //Append the DIV contents.
        frameDoc.document.write(contents);
		//Close the HTML document
        frameDoc.document.write('</body></html>');
        frameDoc.document.close();
        setTimeout(function () {
            window.frames["frame1"].focus();
            window.frames["frame1"].print();
            frame1.remove();
        }, 500);
		$('#ok_sign').fadeOut(); 
		} */
		function printDate(){
		var c_name = $('#name').val();
		var todayTime = new Date();
		var month = todayTime .getMonth() + 1;
		var day = todayTime .getDate();
		var year = todayTime .getFullYear();
		var hour = todayTime .getHours();
		hour = hour % 12;
		hour = hour ? hour : 12;
		var min = todayTime .getMinutes();
		var sec = todayTime .getSeconds();
		document.getElementById("print_date").innerHTML = day+"/"+month+"/"+year+" "+hour+":"+min+":"+sec;
		document.getElementById("print_name").innerHTML ="Name."+c_name;
		window.print();
		$('#ok_sign').fadeOut();
		}
		
		
		
</script>
<?php
include ('inc/footer.php');
?>