<script type="text/javascript">
function unhideBody() {
    var bodyElems = document.getElementsByTagName("body");
    bodyElems[0].style.visibility = "visible";
	$(".se-pre-con").fadeOut("slow");
	}

</script>
</body>
</html>