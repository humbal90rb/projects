<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Login extends CI_Controller{
	
	function __construct()
	{
		parent::__construct();
		 if($this->session->userdata('isLoggedIn'))
		{
		redirect(base_url('dashboard'));
		}  
	}
	function index(){
		$this->load->view('login');		
	}
	function login_or_register(){
		$submit = $this->input->post('submit');
		if($submit == "Login" )
		{
			$username = $this->input->post('l_username');
			$password = $this->input->post('l_password');
			$this->userAthentication($username,$password);
			
		}
		//($this->input->post('register'))
		else if($submit == "Register")
		{
			$name =$this->input->post('r_name');
			$username =$this->input->post('r_username');
			$password = $this->input->post('r_password');
			$this->addUser($name,$username,$password);
		}
	}
	function userAthentication ($username,$password)
	{
		
			$this->load->model('Athentication');
			$res = $this->Athentication->userAth($username,$password);
			if($username == $res->username && $password == $res->password )
			{
				$this->session->set_userdata('isLoggedIn',true);
				$this->session->set_userdata('name',$res->name);
				redirect(base_url('dashboard'));
			}else 
			{
				$this->session->set_flashdata('error_msg', 'Invalid Username/Password!');
				redirect(base_url('login'));
			}
		
	}
	function addUser ($name,$username,$password)
	{
		
		if (empty($name) || empty($username) || empty($password))
		{
			echo "<script> alert ('All fields required!');</script>";
			echo "<script> window.location = '".base_url('signup')."' ;</script>";
		}
		else {
		$this->load->model('register');
		$res =  $this->register->addUser($name,$username,$password);
		if ($res)
		 {
			echo "<script> alert ('User Registered!'); </script>";
			$this->session->set_userdata('isLoggedIn',true);
			$this->session->set_userdata('name',$name);
			redirect(base_url('dashboard'));
		}else
		{
		echo "<script> alert ('Some Error!'); </script>";
		redirect(base_url('signup'));
		}
	}
	}
	
	
}

?>