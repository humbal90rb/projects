
		
		
		
	/* function submitData(){ raw function learn by Sir Shahzaib
	alert('test');
	var accessid = $('#accessid').val();
	var quantity = $('#quantity').val();
alert(accessid);
	 
	$.post("http://localhost/project/dashboard/getData", {accessid:accessid,quantity:quantity}).done(function(data){
		alert(data);
		console.log(data);
	});
}
 */
     